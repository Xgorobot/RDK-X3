#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <std_msgs/msg/string.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <vector>
#include <cmath>
#include <algorithm>
#include <memory>
#include <thread>
#include <QApplication>
#include <QWidget>
#include <QImage>
#include <QPainter>
#include <QColor>
#include <xgoscreen/XgoScreenManager.h>

class LidarDisplayNode : public rclcpp::Node
{
public:
    LidarDisplayNode() : Node("lidar_display_node")
    {
        // 创建订阅器，订阅scan话题
        scan_subscription_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
            "scan", 10,
            std::bind(&LidarDisplayNode::scan_callback, this, std::placeholders::_1));
        
        // 创建发布器，用于调试信息
        debug_publisher_ = this->create_publisher<std_msgs::msg::String>("lidar_debug", 10);
        
        // 初始化屏幕显示参数
        screen_width_ = 320;   // SPI屏幕宽度
        screen_height_ = 240;  // SPI屏幕高度
        center_x_ = screen_width_ / 2;
        center_y_ = screen_height_ / 2;
        max_display_range_ = 5.0;  // 最大显示距离（米）
        
        // 初始化Qt应用和屏幕管理器
        initializeScreen();
        
        RCLCPP_INFO(this->get_logger(), "LiDAR Display Node initialized");
        RCLCPP_INFO(this->get_logger(), "Waiting for scan data on topic: /scan");
    }
    
    ~LidarDisplayNode()
    {
        if (screen_manager_) {
            screen_manager_->stop();
            delete screen_manager_;
        }
        if (widget_) {
            delete widget_;
        }
    }

private:
    void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
    {
        RCLCPP_INFO(this->get_logger(), "Received scan data with %zu points", msg->ranges.size());
        
        // 处理激光雷达数据
        process_scan_data(msg);
        
        // 可视化数据到屏幕
        visualize_on_screen(msg);
        
        // 发布调试信息
        publish_debug_info(msg);
    }
    
    void process_scan_data(const sensor_msgs::msg::LaserScan::SharedPtr msg)
    {
        // 清空之前的点云数据
        display_points_.clear();
        
        float angle = msg->angle_min;
        
        for (size_t i = 0; i < msg->ranges.size(); ++i)
        {
            float range = msg->ranges[i];
            
            // 检查数据有效性
            if (range >= msg->range_min && range <= msg->range_max && 
                range <= max_display_range_ && std::isfinite(range))
            {
                // 将极坐标转换为笛卡尔坐标
                float x = range * cos(angle);
                float y = range * sin(angle);
                
                // 转换为屏幕坐标
                int screen_x = static_cast<int>(center_x_ + (x / max_display_range_) * (screen_width_ / 2 - 10));
                int screen_y = static_cast<int>(center_y_ - (y / max_display_range_) * (screen_height_ / 2 - 10));
                
                // 确保坐标在屏幕范围内
                if (screen_x >= 0 && screen_x < screen_width_ && 
                    screen_y >= 0 && screen_y < screen_height_)
                {
                    display_points_.push_back({screen_x, screen_y, range});
                }
            }
            
            angle += msg->angle_increment;
        }
        
        RCLCPP_DEBUG(this->get_logger(), "Processed %zu valid points for display", display_points_.size());
    }
    
    void visualize_on_screen(const sensor_msgs::msg::LaserScan::SharedPtr msg)
    {
        if (!screen_manager_ || !screen_manager_->isRunning()) {
            RCLCPP_WARN(this->get_logger(), "Screen manager not initialized or not running");
            return;
        }
        
        // 获取背景图像指针进行直接绘制
        QImage* background = screen_manager_->getBackgroundImagePointer();
        if (!background) {
            RCLCPP_ERROR(this->get_logger(), "Failed to get background image pointer");
            return;
        }
        
        // 创建QPainter进行绘制
        QPainter painter(background);
        painter.setRenderHint(QPainter::Antialiasing, true);
        
        // 清空背景为黑色
        painter.fillRect(0, 0, screen_width_, screen_height_, Qt::black);
        
        // 绘制距离圈
        painter.setPen(QPen(Qt::gray, 1));
        for (int i = 1; i <= 5; ++i) {
            int radius = (i * (std::min(screen_width_, screen_height_) / 2 - 20)) / 5;
            painter.drawEllipse(center_x_ - radius, center_y_ - radius, radius * 2, radius * 2);
        }
        
        // 绘制中心点（机器人位置）
        painter.setPen(QPen(Qt::red, 3));
        painter.drawEllipse(center_x_ - 3, center_y_ - 3, 6, 6);
        
        // 绘制激光点
        for (const auto& point : display_points_) {
            QColor color = getDistanceQColor(point.distance);
            painter.setPen(QPen(color, 2));
            painter.drawPoint(point.x, point.y);
        }
        
        // 绘制坐标轴
        painter.setPen(QPen(Qt::darkGray, 1));
        painter.drawLine(center_x_, 0, center_x_, screen_height_); // 垂直线
        painter.drawLine(0, center_y_, screen_width_, center_y_);  // 水平线
        
        // 显示信息文本
        painter.setPen(QPen(Qt::white, 1));
        painter.setFont(QFont("Arial", 10));
        QString info_text = QString("Points: %1 Range: %2m")
                           .arg(display_points_.size())
                           .arg(max_display_range_, 0, 'f', 1);
        painter.drawText(10, 20, info_text);
        
        painter.end();
        
        RCLCPP_DEBUG(this->get_logger(), "Displayed %zu points on screen", display_points_.size());
    }
    
    void publish_debug_info(const sensor_msgs::msg::LaserScan::SharedPtr msg)
    {
        auto debug_msg = std_msgs::msg::String();
        
        // 计算统计信息
        float min_range = *std::min_element(msg->ranges.begin(), msg->ranges.end());
        float max_range = *std::max_element(msg->ranges.begin(), msg->ranges.end());
        
        // 计算有效点数
        size_t valid_points = 0;
        for (float range : msg->ranges)
        {
            if (range >= msg->range_min && range <= msg->range_max && std::isfinite(range))
            {
                valid_points++;
            }
        }
        
        char debug_info[200];
        snprintf(debug_info, sizeof(debug_info),
                "Scan: %zu total, %zu valid, min: %.2fm, max: %.2fm, display: %zu points",
                msg->ranges.size(), valid_points, min_range, max_range, display_points_.size());
        
        debug_msg.data = debug_info;
        debug_publisher_->publish(debug_msg);
    }
    
    QColor getDistanceQColor(float distance)
    {
        // 根据距离返回QColor颜色
        float normalized = std::min(distance / max_display_range_, 1.0f);
        
        if (normalized < 0.3f) {
            return Qt::red;    // 红色 - 近距离
        } else if (normalized < 0.7f) {
            return Qt::yellow; // 黄色 - 中距离
        } else {
            return Qt::green;  // 绿色 - 远距离
        }
    }
    
    void initializeScreen()
    {
        try {
            // 创建QWidget用于屏幕管理
            widget_ = new QWidget();
            widget_->resize(screen_width_, screen_height_);
            
            // 创建屏幕管理器
            screen_manager_ = new XgoScreenManager(widget_);
            
            // 初始化SPI屏幕
            bool success = screen_manager_->initialize(
                1,          // spiController
                0,          // spiDevice
                20000000,   // spiFrequency (20MHz)
                5,          // gpioCS
                13,         // gpioReset
                29,         // gpioDC
                100,        // refreshInterval (100ms)
                false       // fast_startup
            );
            
            if (success) {
                // 设置黑色背景
                screen_manager_->setBackgroundColor(Qt::black);
                RCLCPP_INFO(this->get_logger(), "Screen manager initialized successfully");
            } else {
                RCLCPP_ERROR(this->get_logger(), "Failed to initialize screen manager");
            }
        } catch (const std::exception& e) {
            RCLCPP_ERROR(this->get_logger(), "Exception during screen initialization: %s", e.what());
        }
    }
    
    // 成员变量
    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_subscription_;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr debug_publisher_;
    
    // 屏幕参数
    int screen_width_;
    int screen_height_;
    int center_x_;
    int center_y_;
    float max_display_range_;
    
    // 屏幕管理相关
    QWidget* widget_;
    XgoScreenManager* screen_manager_;
    
    // 显示点结构
    struct DisplayPoint
    {
        int x, y;
        float distance;
    };
    
    std::vector<DisplayPoint> display_points_;
};

int main(int argc, char * argv[])
{
    // 初始化Qt应用
    QApplication app(argc, argv);
    
    // 初始化ROS2
    rclcpp::init(argc, argv);
    
    auto node = std::make_shared<LidarDisplayNode>();
    
    RCLCPP_INFO(node->get_logger(), "Starting LiDAR Display Node...");
    
    try {
        // 在单独线程中运行ROS2 spin
        std::thread ros_thread([&node]() {
            rclcpp::spin(node);
        });
        
        // 运行Qt事件循环
        int result = app.exec();
        
        // 等待ROS线程结束
        rclcpp::shutdown();
        ros_thread.join();
        
        return result;
    } catch (const std::exception& e) {
        RCLCPP_ERROR(node->get_logger(), "Exception in main: %s", e.what());
        rclcpp::shutdown();
        return -1;
    }
}